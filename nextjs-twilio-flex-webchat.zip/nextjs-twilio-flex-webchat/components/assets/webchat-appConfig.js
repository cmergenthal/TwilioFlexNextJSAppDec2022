import {brandedColors} from './webchat-branding.js';

var customerName = "";

const appConfig = (context) => {
    var appConfigObj = {
        //  Your AccountSid
        accountSid: "AC39f053529492fbd4d293c5c0ed61aa3d",
        // change to your Flex Flow SID
        flexFlowSid: "FOb4bef82209ce00560a497299ed95a796",

        // Your Flex Flow SID

        showReadStatus: true,
        colorTheme: {
            overrides: brandedColors
        },
    
    
        //componentProps: {identity: "testuser",contactIdentity: "testuser"},
        //identity: "testuser",contactIdentity: "testuser",
    
        tokenServerUrl: "https://iam.twilio.com/v1/Accounts/{accountSid}/Tokens",
        flexWebChannelsUrl: "https://flex-api.twilio.com/v1/WebChannels",
        context: context,
        /** 
        context: {
            friendlyName: "testUserName",
            chatFriendlyName: "testUserName",
            identity: "testuserContext",
            contactIdentity: "testuserContext"
        },
        sdkOptions: {
            chat: {identity: "testuser"},
            identity: "testuser"
        },
        chatFriendlyName: "testUserName",*/
        startEngagementOnInit: false,
        preEngagementConfig: {    
    
            description: "Please provide some information",
            fields: [
                {
                    label: "What is your name?",
                    type: "InputItem",
                    attributes: {
                        name: "friendlyName",
                        type: "text",
                        required: true//,
                        //value: customerName
                    }
                },
                {
                    label: "What is your phone number?",
                    type: "InputItem",
                    attributes: {
                        name: "friendlyNumber",
                        type: "text",
                        required: true
                    }
                },
                {
                    label: "How would you like to be contated?",
                    type: "SelectItem",
                    attributes: {
                        name: "chatOrSMS",
                        required: true,
                        readOnly: false
           
                    },
                    options: [
                    {
                        value: "SMS",
                        label: "SMS",
                        selected: false
                    },
                    {
                        value: "Chat",
                        label: "Chat",
                        selected: true
                    }
                    ]
                },
                {
                    label: "What timezone are you in?",
                    type: "SelectItem",
                    attributes: {
                        name: "Timezone",
                        required: true,
                        readOnly: false
           
                    },
                    options: [
                    {
                        value: "ET",
                        label: "ET",
                        selected: false
                    },
                    {
                        value: "CT",
                        label: "CT",
                        selected: true
                    },
                    {
                        value: "MT",
                        label: "MT",
                        selected: true
                    },
                    {
                        value: "PT",
                        label: "PT",
                        selected: true
                    }
                    ]
                },
                {
                    label: "What is your question?",
                    type: "TextareaItem",
                    attributes: {
                        name: "question",
                        type: "text",
                        placeholder: "Type your question here",
                        required: false,
                        rows: 5
                    }
                }, 
            ],
            submitLabel: "Ok Let's Go!"
        }
    }
    return appConfigObj
}

export default appConfig;