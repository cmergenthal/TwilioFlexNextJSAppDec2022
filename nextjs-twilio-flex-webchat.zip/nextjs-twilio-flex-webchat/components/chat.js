import React from 'react';
import * as FlexWebChat from "@twilio/flex-webchat-ui";

import appConfig from './assets/webchat-appConfig';
import { useEffect } from 'react';


const Chat = (context) => {




useEffect(()=>{
    console.log("jello 1", context)
   

    FlexWebChat.createWebChat(appConfig(context)).then(webchat => {
        const { manager } = webchat;
        
        //Posting question from preengagement form as users first chat message
            FlexWebChat.Actions.on("afterStartEngagement", (payload) => {
                const { question } = payload.formData;
                if (!question)
                    return;

                const { channelSid } = manager.store.getState().flex.session;
                manager
                    .chatClient.getChannelBySid(channelSid)
                    .then(channel => channel.sendMessage(question));
            });
        // Changing the Welcome message
            manager.strings.WelcomeMessage = "New text for welcome message";

        // Render WebChat
        webchat.init();
        })

        FlexWebChat.Actions.invokeAction("ToggleChatVisibility");

},[])

useEffect(()=>{
    console.log("jello 2", context)
    FlexWebChat.Actions.invokeAction("RestartEngagement");
},[context])

    return(
        null
    )
}



export default Chat;