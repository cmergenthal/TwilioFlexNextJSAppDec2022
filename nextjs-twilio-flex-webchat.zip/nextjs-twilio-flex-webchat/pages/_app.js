import '../styles/globals.css'
import '../components/assets/webchat-branding.js'
import '../components/assets/webchat-appConfig.js'


//<script id="my-script" src="https://assets.flex.twilio.com/releases/flex-webchat-ui/2.8.1/twilio-flex-webchat.min.js" integrity="sha512-KzpB56iRohSbDOkfM/V0PTp9DGHMno2EJJx6Zg8Ul3byOV3xtAurIZ+NibcO+cc0SEDvodI/5SKMSv2p+gwSYw==" crossOrigin="anonymous" >
//</script>


function MyApp({ Component, pageProps }) {
  return (
   <>
<script id="my-script" src="https://assets.flex.twilio.com/releases/flex-webchat-ui/2.9.1/twilio-flex-webchat.min.js" integrity="sha512-yBmOHVWuWT6HOjfgPYkFe70bboby/BTj9TGHXTlEatWnYkW5fFezXqW9ZgNtuRUqHWrzNXVsqu6cKm3Y04kHMA==" crossOrigin="anonymous" >
</script>


    <Component {...pageProps} />
  </>
  )
}

export default MyApp
